# 초기설정
1. 소스코드 로칼로 clone 처리
2. nodejs 설치
3. 프로젝트에 필요한 라이브러리 설치
  $ npm install
4. 로칼에서 실행 테스트
  $ npm run dev
