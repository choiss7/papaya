import 'bootstrap/dist/css/bootstrap.min.css';

import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Sidebar from './components/Sidebar';

import ProjectList from './components/ProjectList';
import ProjectNew from './components/ProjectNew';
import ProjectDetail from './components/ProjectDetail';
import ProjectEdit from './components/ProjectEdit';
import ProjectSearch from './components/ProjectSearch';

import DataSourceList from './components/DataSourceList';
import DataSourceNew from './components/DataSourceNew';
import DataSourceDetail from './components/DataSourceDetail';

import SssRagList from './components/SssRagList';
import SssAnalysisList from './components/SssAnalysisList';

import SssUpload from './components/SssUpload';

import IndexNew from './components/IndexNew';
import IndexList from './components/IndexList'

import './App.css'

function App() {

  return (
    <Router>
      <div className="app">
        <Sidebar />
        <div className="content">
          <Routes>
            <Route exact path="/" element={<ProjectList/>} />
            <Route path="/project" element={<ProjectList/>} />
            <Route path="/project/new" element={<ProjectNew/>} />
            <Route path="/project/:id" element={<ProjectDetail/>} />
            <Route path="/project/:id/edit" element={<ProjectEdit/>} />
            <Route path="/project/:id/search" element={<ProjectSearch/>} />
            
            <Route path="/ds/:id" element={<DataSourceList/>} />
            <Route path="/ds/detail/:id/:ds_id" element={<DataSourceDetail/>} />
            <Route path="/ds/new/:id" element={<DataSourceNew/>} />

            <Route path="/sss/rag/:id" element={<SssRagList/>} />
            <Route path="/sss/analysis/:id" element={<SssAnalysisList/>} />
            <Route path="/sss/upload/:id/:bucket" element={<SssUpload/>} />

            <Route path="/index" element={<IndexList/>} />
            <Route path="/index/new" element={<IndexNew/>} />

          </Routes>
        </div>
      </div>
    </Router>
  )
}

export default App

