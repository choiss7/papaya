import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';
import { SyncLoader } from "react-spinners";

function IndexNew() {

    const navigate = useNavigate();
    const [loading, setLoading] = useState(false);
    const [project, setProject] = useState([{ name: '', desc: '', tag: '' }]);
    
    const handleChange = (e) => {
        const { name, value } = e.target;
        setProject(prevInputs => ({
          ...prevInputs,
          [name]: value
        }));
      };


    const handleNewProject = async (e) => {
        
        // 기본 동작 방지 (필요한 경우)
        e.preventDefault();

        if (!project.name || project.name.trim() === '') {
            alert('프로젝트 이름 값이 비어 있습니다!');
            return; // 값이 없을 경우 함수 종료
        }

        try {

            setLoading(true);
            const URL = 'https://byf0qor8fe.execute-api.us-east-1.amazonaws.com/prod'
            const response = await axios.get(URL, {
                params: {
                    index_name: project.name,
                }
            });

            console.log('서버 응답:', response);
            
            alert('벡터 인덱스가 성공적으로 생성되었습니다!');
            navigate('/index')

        } catch (error) {
            // 오류 처리
            console.error('벡터 인덱스 생성 중 오류가 발생했습니다:', error);
            alert('벡터 인덱스 생성에 실패했습니다.');
        } finally {
            setLoading(false); // 요청 완료 후 로딩 상태를 false로 설정
        }
    };

    const handleCancel = (event) => {
        // 기본 동작 방지 (필요한 경우)
        event.preventDefault();
        
        navigate(-1);
    };

    if (loading) return (
        <div>
            <h3>벡터 인덱스 생성중입니다.</h3>
            <SyncLoader />
        </div>
    );

    return (
        <div>
            {/* 타이틀 영역 */}
            <div className='text-start'>
                <p className="fs-4 fw-bolder">벡터 인덱스 생성</p>
            </div>
            {/* 버튼 영역 */}
            <div className="d-flex justify-content-end">
                <Link to="/index" className='btn btn-primary m-1'>벡터 인덱스 목록</Link>
                <Link onClick={handleNewProject} className='btn btn-primary m-1'>생성</Link>
            </div>
            <div className="container mt-5 ">
                <table className="table text-start table-bordered">
                    <tbody>
                        {/* <tr>
                            <td className='px-3 py-2'>id</td>
                            <td className='px-3 py-2'>{project.id} (파라미터:{id})</td>
                        </tr>*/}
                        <tr>
                            <td style={{width: "140px"}} className='px-3 py-2'>벡터 인덱스 명</td>
                            <td className='px-3 py-2'>
                                <input
                                    type="text"
                                    id="name"
                                    name="name"
                                    className='w-100'
                                    value={project.name}
                                    onChange={handleChange}
                                    />
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    )
}

export default IndexNew;