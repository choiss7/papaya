import { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import { SyncLoader } from "react-spinners";

function ProjectList() {
  const [projectList, setProjectList] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const URL = import.meta.env.VITE_URL_KB_LIST;
    axios
      .get(URL)
      .then((response) => {
        console.log(response);
        setProjectList(response.data);
      })
      .catch((error) => {
        console.error("Error fetching data: ", error);
      })
      .finally(() => {
        setLoading(false);
      });
  }, []);

  if (loading)
    return (
      <div>
        <h3>프로젝트 목록을 가져오는 중입니다.</h3>
        <SyncLoader />
      </div>
    );

  return (
    <div className="container">
      {/* 타이틀 영역 */}
      <div className="text-start">
        <p className="fs-4 fw-bolder">프로젝트 목록</p>
      </div>
      {/* 버튼 영역 */}
      <div className="d-flex justify-content-end">
        <Link to="/project/new" className="btn btn-primary m-1">
          프로젝트 생성
        </Link>
        <Link to="http://44.209.68.226:8501/" className="btn btn-primary m-1">
          AI 챗봇 (베타)
        </Link>
      </div>
      {/* 리스트 영역 */}
      <div>
        <table className="table">
          <thead>
            <tr>
              <th scope="col">이름</th>
              <th scope="col">설명</th>
              <th scope="col">상태</th>
              <th scope="col">생성날짜</th>
              <th scope="col">데이터 소스</th>
              <th scope="col">RAG 파일</th>
              <th scope="col">분석용 파일</th>
            </tr>
          </thead>
          <tbody>
            {projectList &&
              projectList.map((project) => (
                <tr key={project.id}>
                  <td>
                    <Link to={`/project/${project.id}`}>{project.name}</Link>
                  </td>
                  <td>{project.description}</td>
                  <td>{project.status}</td>
                  <td>{project.updatedAt}</td>
                  <td>
                    <Link to={`/ds/${project.id}`}>이동</Link>
                  </td>
                  <td>
                    <Link to={`/sss/rag/${project.id}`}>이동</Link>
                  </td>
                  <td>
                    <Link to={`/sss/analysis/${project.id}`}>이동</Link>
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default ProjectList;
