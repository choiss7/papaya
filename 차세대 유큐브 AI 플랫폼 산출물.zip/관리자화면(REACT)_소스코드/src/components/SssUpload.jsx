import { useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { SyncLoader } from "react-spinners";

const SssUpload = () => {
  const { id, bucket } = useParams();

  const [files, setFiles] = useState(null);
  const navigate = useNavigate();
  const [loading, setLoading] = useState(""); // 로딩 상태 추가

  const handleFileChange = (e) => {
    setFiles(e.target.files); // 파일 선택 시 파일 상태 업데이트
  };

  const handleLargeFileUploads = async () => {
    if (!files || files.length === 0) {
      alert("파일을 선택하세요.");
      return;
    }

    try {
      setLoading("업로드 준비중");

      // files 배열을 순회하면서 각 파일을 업로드 (index도 함께 꺼냄)
      for (const [index, file] of Array.from(files).entries()) {
        const fileName = file.name;
        const fileType = file.type;

        // First, get presigned url of s3
        const URL1 = import.meta.env.VITE_URL_S3_PRESIGNED_URL;
        const response1 = await axios.get(URL1, {
          params: {
            file_name: fileName,
            file_type: fileType,
            kb_id: id,
            sub_bucket: bucket,
          },
        });

        console.log(`response1 for file ${index}:`, response1.data);

        // 파일 업로드
        const response2 = await axios.put(response1.data, file, {
          headers: {
            "Content-Type": file.type, // 파일의 MIME 타입을 지정
          },
          onUploadProgress: (progressEvent) => {
            const { loaded, total } = progressEvent;
            let percentage = Math.floor((loaded * 100) / total);

            // 각 파일의 업로드 진행률을 표시
            setLoading(
              `파일 ${
                index + 1
              } : "${fileName}" 업로드 중 : ${percentage}% 완료`
            );
          },
        });

        console.log(`response2 for file ${index}:`, response2.data);
      }

      alert("모든 파일이 성공적으로 업로드되었습니다.");
    } catch (error) {
      console.error("파일 업로드 중 오류 발생:", error);
      alert("파일 업로드에 실패했습니다.");
    } finally {
      setLoading("");
      navigate("/sss/" + bucket + "/" + id);
    }
  };

  if (loading)
    return (
      <div>
        <h3>
          파일 업로드 중입니다. <br></br>({loading})
        </h3>
        <SyncLoader />
      </div>
    );

  return (
    <div>
      <h2>파일 업로드</h2>
      <input
        type="file"
        multiple
        accept=".md, .txt, .html, .doc, .docx, .csv, .xls, .xlsx, .pdf"
        onChange={handleFileChange}
      />
      <button onClick={handleLargeFileUploads}>업로드</button>
    </div>
  );
};

export default SssUpload;
