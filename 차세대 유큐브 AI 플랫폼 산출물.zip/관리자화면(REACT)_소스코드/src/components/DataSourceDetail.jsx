import { useState, useEffect } from "react";
import axios from "axios";
import { Link, useParams } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { SyncLoader } from "react-spinners";

function DataSourceDetail() {
  const params = useParams();

  var id = params.id;
  var ds_id = params.ds_id;

  const [project, setProject] = useState([]);
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [updating, setUpdating] = useState(false);

  const navigate = useNavigate();

  useEffect(() => {
    const URL = import.meta.env.VITE_URL_DS_DETAIL;

    axios
      .get(URL, {
        params: {
          kb_id: id,
          ds_id: ds_id,
        },
      })
      .then((response) => {
        console.log(response);
        setProject(response.data);
      })
      .catch((error) => {
        console.error("Error fetching data: ", error);
        alert("데이터 소스를 가져오는데 실패하였습니다.");
        navigate("/project");
      })
      .finally(() => {
        setLoading(false);
      });
  }, [id, ds_id, navigate]);

  // 주기적으로 상태를 업데이트하는 로직 추가
  useEffect(() => {
    const interval = setInterval(async () => {
      const statuses = ["COMPLETE", "FAILED", "STOPPED"];

      // 상태가 statuses에 속하면 타이머 중단
      if (statuses.includes(project.job_status)) {
        clearInterval(interval);
        return;
      }

      try {
        const URL = import.meta.env.VITE_URL_DS_DETAIL;
        const response = await axios.get(URL, {
          params: {
            kb_id: id,
            ds_id: ds_id,
          },
        });

        console.log("Updated job status:", response.data.job_status);
        setProject(response.data);
      } catch (error) {
        console.error("Error updating job status: ", error);
      }
    }, 3000); // 3초마다 상태 조회

    // 컴포넌트 언마운트 시 타이머 제거
    return () => clearInterval(interval);
  }, [project.job_status, id, ds_id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setProject((prevInputs) => ({
      ...prevInputs,
      [name]: value,
    }));
  };

  const handleUpdateDataSource = async (e) => {
    // 기본 동작 방지 (필요한 경우)
    e.preventDefault();

    if (!project.name || project.name.trim() === "") {
      alert("프로젝트 이름 값이 비어 있습니다!");
      return; // 값이 없을 경우 함수 종료
    }

    try {
      setUpdating(true);
      const URL = import.meta.env.VITE_URL_DS_UPDATE;
      const response = await axios.get(URL, {
        params: {
          kb_id: id,
          ds_id: ds_id,
          name: project.name,
          description: project.description,
        },
      });

      console.log("서버 응답:", response);

      alert("데이터 소스가 성공적으로 업데이트 되었습니다!");
      navigate("/ds/detail/" + id + "/" + ds_id);
    } catch (error) {
      // 오류 처리
      console.error("데이터 소스 업데이트 중 오류가 발생했습니다:", error);

      if (error.response.status == 409) {
        alert("이미 같은 이름의 데이터 소스가 존재합니다.");
      } else if (error.response.status == 400) {
        alert("데이터 소스 생성시 인자값이 잘못되었습니다.");
      } else {
        alert("데이터 소스 업데이트에 실패했습니다.");
      }
    } finally {
      setUpdating(false); // 요청 완료 후 로딩 상태를 false로 설정
    }
  };

  const handleSyncRAGFiles = async (event) => {
    event.preventDefault();

    const userConfirmed = confirm("해당 데이터 소스를 동기화 하시겠습니까?");

    if (userConfirmed) {
      try {
        setSyncing(true);

        const URL = import.meta.env.VITE_URL_DS_INJEST;

        const response = await axios.get(URL, {
          params: {
            kb_id: id,
            ds_id: ds_id,
          },
        });

        console.log("response :", response);

        alert("데이터 소스 동기화가 성공적으로 시작되었습니다!");
        project.job_status = "STARTING";
      } catch (error) {
        console.error("데이터 소스 동기화 중 오류가 발생했습니다:", error);
        alert("데이터 소스 동기화에 실패했습니다.");
      } finally {
        setSyncing(false);
      }
    } else {
      console.log("동기화가 취소되었습니다.");
    }
  };

  const handleDelete = async (event) => {
    event.preventDefault();

    const userConfirmed = confirm(
      "해당 데이터 소스를 정말로 삭제하시겠습니까?"
    );

    if (userConfirmed) {
      try {
        setDeleting(true);

        const URL = import.meta.env.VITE_URL_DS_DELETE;

        const response = await axios.get(URL, {
          params: {
            kb_id: id,
            ds_id: ds_id,
          },
        });

        console.log("response :", response);

        alert("데이터 소스가 성공적으로 삭제되었습니다!");
        navigate("/ds/" + id);
      } catch (error) {
        console.error("데이터 소스 삭제 중 오류가 발생했습니다:", error);
        alert("데이터 소스 삭제에 실패했습니다.");
      } finally {
        setDeleting(false);
      }
    } else {
      console.log("삭제가 취소되었습니다.");
    }
  };

  if (loading)
    return (
      <div>
        <h3>데이터 소스 상세를 가져오는 중입니다.</h3>
        <SyncLoader />
      </div>
    );

  if (deleting)
    return (
      <div>
        <h3>데이터 소스를 삭제하는 중입니다.</h3>
        <SyncLoader />
      </div>
    );

  if (syncing)
    return (
      <div>
        <h3>데이터 소스를 동기화 중입니다.</h3>
        <SyncLoader />
      </div>
    );

  if (updating)
    return (
      <div>
        <h3>데이터 소스를 업데이트 중입니다.</h3>
        <SyncLoader />
      </div>
    );

  return (
    <div>
      {/* 타이틀 영역 */}
      <div className="text-start">
        <p className="fs-4 fw-bolder">데이터 소스 상세</p>
      </div>
      {/* 버튼 영역 */}
      <div className="d-flex justify-content-end">
        <Link to={`/project/${id}`} className="btn btn-primary m-1">
          프로젝트 상세
        </Link>
        <Link to={`/ds/${id}`} className="btn btn-primary m-1">
          데이터 소스 목록
        </Link>
      </div>
      <div className="d-flex justify-content-end">
        <Link onClick={handleSyncRAGFiles} className="btn btn-primary m-1">
          동기화
        </Link>
        <Link onClick={handleUpdateDataSource} className="btn btn-primary m-1">
          업데이트
        </Link>
        <Link onClick={handleDelete} className="btn btn-primary m-1 btn-red">
          삭제
        </Link>
      </div>
      <div className="container mt-5 ">
        <table className="table text-start table-bordered">
          <tbody>
            <tr>
              <td style={{ width: "160px" }} className="px-3 py-2">
                데이터 소스 ID
              </td>
              <td className="px-3 py-2">{project.id}</td>
            </tr>
            <tr>
              <td style={{ width: "140px" }} className="px-3 py-2">
                프로젝트 ID
              </td>
              <td className="px-3 py-2">{project.kb_id}</td>
            </tr>
            <tr>
              <td className="px-3 py-2">데이터 소스 이름</td>
              <td className="px-3 py-2">
                <input
                  type="text"
                  id="name"
                  name="name"
                  className="w-100"
                  value={project.name}
                  onChange={handleChange}
                />
              </td>
            </tr>
            <tr>
              <td className="px-3 py-2">데이터 소스 설명</td>
              <td className="px-3 py-2">
                <input
                  type="text"
                  id="description"
                  name="description"
                  className="w-100"
                  value={project.description}
                  onChange={handleChange}
                />
              </td>
            </tr>
            <tr>
              <td className="px-3 py-2">S3 데이터</td>
              <td className="px-3 py-2">{project.s3}</td>
            </tr>
            <tr>
              <td className="px-3 py-2">생성일시</td>
              <td className="px-3 py-2">{project.createdAt}</td>
            </tr>
            <tr>
              <td className="px-3 py-2">데이터 보존 정책</td>
              <td className="px-3 py-2">{project.policy}</td>
            </tr>
            <tr>
              <td className="px-3 py-2">청킹 전략</td>
              <td className="px-3 py-2">{project.vector_strategy}</td>
            </tr>
            <tr>
              <td className="px-3 py-2">청킹 전략 상세 수치</td>
              <td className="px-3 py-2">
                최대 토큰 : {project.token} / 오버랩 비율 : {project.overlap}%
              </td>
            </tr>
            <tr>
              <td className="px-3 py-2">마지막 작업 상태</td>
              <td className="px-3 py-2">
                {project.job_status === "IN_PROGRESS" ? (
                  <>
                    <SyncLoader size={8} color={"#36d7b7"} />{" "}
                    {/* Or any other spinner */}
                    <span className="ms-2">동기화 진행 중...</span>
                  </>
                ) : (
                  project.job_status
                )}
              </td>
            </tr>
            <tr>
              <td className="px-3 py-2">마지막 작업 시작시간</td>
              <td className="px-3 py-2">{project.job_start}</td>
            </tr>
            <tr>
              <td className="px-3 py-2">스캔한 문서</td>
              <td className="px-3 py-2">{project.job_doc_scan}</td>
            </tr>
            <tr>
              <td className="px-3 py-2">새로 추가된 문서</td>
              <td className="px-3 py-2">{project.job_doc_new}</td>
            </tr>
            <tr>
              <td className="px-3 py-2">수정된 문서</td>
              <td className="px-3 py-2">{project.job_doc_modify}</td>
            </tr>
            <tr>
              <td className="px-3 py-2">실패한 문서</td>
              <td className="px-3 py-2">{project.job_doc_fail}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default DataSourceDetail;
