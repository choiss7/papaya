import { useState, useEffect } from "react";
import axios from "axios";
import { Link, useParams } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { SyncLoader } from "react-spinners";

function ProjectDetail() {
  const { id } = useParams();

  const [project, setProject] = useState([]);
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState(false);
  const [updating, setUpdating] = useState(false);

  const navigate = useNavigate();

  useEffect(() => {
    const URL = import.meta.env.VITE_URL_KB_DETAIL;

    axios
      .get(URL, {
        params: {
          kb_id: id,
        },
      })
      .then((response) => {
        console.log(response);
        setProject(response.data);
      })
      .catch((error) => {
        console.error("Error fetching data: ", error);
        alert("프로젝트를 가져오는데 실패하였습니다.");
        navigate("/project");
      })
      .finally(() => {
        setLoading(false);
      });
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setProject((prevInputs) => ({
      ...prevInputs,
      [name]: value,
    }));
  };

  const handleUpdateProject = async (e) => {
    // 기본 동작 방지 (필요한 경우)
    e.preventDefault();

    if (!project.name || project.name.trim() === "") {
      alert("프로젝트 이름 값이 비어 있습니다!");
      return; // 값이 없을 경우 함수 종료
    }

    try {
      setUpdating(true);

      const URL1 = import.meta.env.VITE_URL_KB_UPDATE;
      const response1 = await axios.get(URL1, {
        params: {
          kb_id: id,
          name: project.name,
          description: project.description,
        },
      });

      console.log("서버 응답:", response1);

      const URL2 = import.meta.env.VITE_URL_TEMPLATE_CREATE;

      const response2 = await axios.get(URL2, {
        params: {
          kb_id: id,
          prompt: project.prompt,
        },
      });

      console.log("response2 : ", response2);

      alert("프로젝트가 성공적으로 업데이트 되었습니다!");
      navigate("/project/" + project.id);
    } catch (error) {
      // 오류 처리
      console.error("프로젝트 업데이트 중 오류가 발생했습니다:", error);

      if (error.response.status == 409) {
        alert("이미 같은 이름의 프로젝트가 존재합니다.");
      } else if (error.response.status == 400) {
        alert("프로젝트 업데이트 시 인자값이 잘못되었습니다.");
      } else {
        alert("프로젝트 업데이트에 실패했습니다.");
      }
    } finally {
      setUpdating(false); // 요청 완료 후 로딩 상태를 false로 설정
    }
  };

  const handleDelete = async (event) => {
    event.preventDefault();

    const userConfirmed = confirm("해당 프로젝트를 정말로 삭제하시겠습니까?");

    if (userConfirmed) {
      try {
        setDeleting(true);

        const URL1 = import.meta.env.VITE_URL_KB_DELETE;

        const response1 = await axios.get(URL1, {
          params: {
            kb_id: id,
          },
        });

        console.log("response 1 :", response1);

        const URL2 = import.meta.env.VITE_URL_INDEX_DELETE;

        const response2 = await axios.get(URL2, {
          params: {
            index_name: project.indexName,
          },
        });

        console.log("response 2 :", response2);

        alert("프로젝트가 성공적으로 삭제되었습니다!");
        navigate("/project");
      } catch (error) {
        console.error("프로젝트 삭제 중 오류가 발생했습니다:", error);
        alert("프로젝트 삭제에 실패했습니다.");
      } finally {
        setDeleting(false);
      }
    } else {
      console.log("삭제가 취소되었습니다.");
    }
  };

  if (loading)
    return (
      <div>
        <h3>프로젝트 상세를 가져오는 중입니다.</h3>
        <SyncLoader />
      </div>
    );

  if (deleting)
    return (
      <div>
        <h3>프로젝트를 삭제하는 중입니다.</h3>
        <SyncLoader />
      </div>
    );

  if (updating)
    return (
      <div>
        <h3>프로젝트를 업데이트 중입니다.</h3>
        <SyncLoader />
      </div>
    );

  return (
    <div>
      {/* 타이틀 영역 */}
      <div className="text-start">
        <p className="fs-4 fw-bolder">프로젝트 상세</p>
      </div>
      {/* 버튼 영역 */}
      <div className="d-flex justify-content-end">
        {/*<Link to={`/project/${id}/edit`} className='btn btn-primary m-1'>수정</Link>*/}
        <Link to={`/ds/${id}`} className="btn btn-primary m-1">
          데이터 소스 목록
        </Link>
        <Link to={`/sss/rag/${id}`} className="btn btn-primary m-1">
          RAG 파일 목록
        </Link>
        <Link to={`/sss/analysis/${id}`} className="btn btn-primary m-1">
          분석용 파일 목록
        </Link>
      </div>
      <div className="d-flex justify-content-end">
        <Link onClick={handleUpdateProject} className="btn btn-primary m-1">
          업데이트
        </Link>
        <Link onClick={handleDelete} className="btn btn-primary m-1 btn-red">
          삭제
        </Link>
      </div>
      <div className="container mt-5 ">
        <table className="table text-start table-bordered">
          <tbody>
            <tr>
              <td style={{ width: "180" }} className="px-3 py-2">
                프로젝트 ID
              </td>
              <td className="px-3 py-2">{project.id}</td>
            </tr>
            <tr>
              <td className="px-3 py-2">프로젝트 이름</td>
              <td className="px-3 py-2">
                <input
                  type="text"
                  id="name"
                  name="name"
                  className="w-100"
                  value={project.name}
                  onChange={handleChange}
                />
              </td>
            </tr>
            <tr>
              <td className="px-3 py-2">프로젝트 설명</td>
              <td className="px-3 py-2">
                <input
                  type="text"
                  id="description"
                  name="description"
                  className="w-100"
                  value={project.description}
                  onChange={handleChange}
                />
              </td>
            </tr>
            <tr>
              <td className="px-3 py-2">프롬프트</td>
              <td className="px-3 py-2">
                <textarea
                  className="form-control"
                  id="prompt"
                  name="prompt"
                  rows="5"
                  value={project.prompt ?? ""}
                  onChange={handleChange}
                  defaultValue=""
                ></textarea>
              </td>
            </tr>
            <tr>
              <td className="px-3 py-2">임베딩 모델</td>
              <td className="px-3 py-2">
                {project.embeddingModel} (DIMENSION : {project.dimensions})
              </td>
            </tr>
            <tr>
              <td className="px-3 py-2">생성날짜</td>
              <td className="px-3 py-2">{project.createdAt}</td>
            </tr>
            <tr>
              <td className="px-3 py-2">스토리지 타입</td>
              <td className="px-3 py-2">{project.storageType}</td>
            </tr>
            <tr>
              <td className="px-3 py-2">벡터 인덱스 명</td>
              <td className="px-3 py-2">{project.indexName}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default ProjectDetail;
