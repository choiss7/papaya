import { useState, useEffect } from "react";
import axios from "axios";
import { Link, useParams } from "react-router-dom";
import { SyncLoader } from "react-spinners";

function SssRagList() {
  const { id } = useParams();

  const [projectList, setProjectList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const URL = import.meta.env.VITE_URL_S3_LIST;
    axios
      .get(URL, {
        params: {
          kb_id: id,
          sub_bucket: "rag",
        },
      })
      .then((response) => {
        console.log(response);
        setProjectList(response.data);
      })
      .catch((error) => {
        console.error("Error fetching data: ", error);
      })
      .finally(() => {
        setLoading(false);
      });
  }, [id]);

  if (loading)
    return (
      <div>
        <h3>RAG 파일 목록을 가져오는 중입니다.</h3>
        <SyncLoader />
      </div>
    );

  const handleDelete = async (file) => {
    const userConfirmed = confirm(`${file} 파일을 삭제하시겠습니까?`);

    if (userConfirmed) {
      try {
        setDeleting(true);

        const URL = import.meta.env.VITE_URL_S3_DELETE;

        const response = await axios.get(URL, {
          params: {
            kb_id: id,
            file_name: file,
            sub_bucket: "rag",
          },
        });

        console.log("response:", response);

        // 프로젝트 목록에서 해당 파일 삭제
        setProjectList((prevProjects) =>
          prevProjects.filter((project) => project.file !== file)
        );

        // 추가 처리 (예: 성공 시 알림 또는 페이지 이동)
        alert(`"${file}" 파일이 삭제되었습니다.`);
      } catch (error) {
        // 오류 처리
        console.error("파일 삭제 중 오류가 발생했습니다:", error);
        alert("파일 삭제에 실패했습니다.");
      } finally {
        setDeleting(false);
      }
    } else {
      console.log("삭제가 취소되었습니다.");
    }
  };

  if (deleting)
    return (
      <div>
        <h3>파일 삭제 중입니다.</h3>
        <SyncLoader />
      </div>
    );

  return (
    <div className="container">
      {/* 타이틀 영역 */}
      <div className="text-start">
        <p className="fs-4 fw-bolder">RAG 파일 목록 (지식기반 ID : {id})</p>
      </div>
      {/* 버튼 영역 */}
      <div className="d-flex justify-content-end">
        <Link to={`/ds/${id}`} className="btn btn-primary m-1">
          데이터 소스 목록
        </Link>
        <Link to={`/sss/upload/${id}/rag`} className="btn btn-primary m-1">
          RAG 파일 업로드
        </Link>
      </div>
      {/* 리스트 영역 */}
      <div>
        <table className="table">
          <thead>
            <tr>
              <th scope="col">이름</th>
              <th scope="col">크기</th>
              <th scope="col">수정날짜</th>
              <th scope="col">삭제</th>
            </tr>
          </thead>
          <tbody>
            {projectList &&
              projectList.map((project) => (
                <tr key={project.file}>
                  <td>{project.file}</td>
                  <td>{project.size}</td>
                  <td>{project.modifiedAt}</td>
                  <td>
                    <button
                      onClick={() => handleDelete(project.file)}
                      className="btn btn-danger"
                    >
                      🗑️
                    </button>
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default SssRagList;
