import { useState, useEffect } from 'react';
import axios from 'axios';
import { Link, useParams } from 'react-router-dom';
import { SyncLoader } from "react-spinners";

function IndexList() {

    const { id } = useParams();

    const [projectList, setProjectList] = useState([]);
    const [loading, setLoading] = useState(true);
    const [deleting, setDeleting] = useState(false);

    useEffect(() => {

        // 'https://i6m52i7ezj.execute-api.us-east-1.amazonaws.com/prod'
        const URL = import.meta.env.VITE_URL_INDEX_LIST
        axios.get(URL)
          .then(response => {
            console.log(response);
            setProjectList(response.data);
            setLoading(false);
          })
          .catch(error => {
            console.error('Error fetching data: ', error);
          });
      }, []);
    
    if (loading) return (
        <div>
            <h3>벡터 인덱스 목록을 가져오는 중입니다.</h3>
            <SyncLoader />
        </div>
    );

    const handleDelete = async (index_name) => {

        const userConfirmed = confirm(`${index_name} 벡터 인덱스를 삭제하시겠습니까?`);

        if (userConfirmed) {
            
            try {

                setDeleting(true)
                const URL = 'https://2pmh6z3orb.execute-api.us-east-1.amazonaws.com/prod'
                const response = await axios.get(URL, {params: {
                    index_name: index_name
                }
                });
    
                // 서버에서 받은 응답 데이터 확인
                console.log('서버 응답:', response);

                // 프로젝트 목록에서 해당 파일 삭제
                setProjectList(prevProjects => prevProjects.filter(project => project.index_name !== index_name));
                
                // 추가 처리 (예: 성공 시 알림 또는 페이지 이동)
                alert(`${index_name} 벡터 인덱스가 삭제되었습니다.`);
    
            } catch (error) {
                // 오류 처리
                console.error('벡터 인덱스 삭제 중 오류가 발생했습니다:', error);
                alert('벡터 인덱스 삭제에 실패했습니다.');
            } finally {
                setDeleting(false);
            }
        } else {
            // 사용자가 취소를 눌렀을 때 수행할 작업
            console.log('삭제가 취소되었습니다.');
        }
    
    };

    if (deleting) return (
        <div>
            <h3>벡터 인덱스 삭제 중입니다.</h3>
            <SyncLoader />
        </div>
      )

    return (
        <div className="container">
            {/* 타이틀 영역 */}
            <div className='text-start'>
                <p className="fs-4 fw-bolder">벡터 인덱스 목록</p>
            </div>
            {/* 버튼 영역 */}
            <div className="d-flex justify-content-end">
                <Link to={`/index/new`} className='btn btn-primary m-1'>벡터 인덱스 생성</Link>
            </div>
            {/* 리스트 영역 */}
            <div>
                <table className="table">
                    <thead>
                        <tr>
                        <th scope="col">인덱스 명</th>
                        <th scope="col">삭제</th>
                        </tr>
                    </thead>
                    <tbody>
                        {projectList && projectList.map(project => (
                            <tr key={project.index_name}>
                                <td>{project.index_name}</td>
                                <td>
                                    <button
                                        onClick={() => handleDelete(project.index_name)}
                                        className="btn btn-danger"
                                    >🗑️
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    )
}

export default IndexList;