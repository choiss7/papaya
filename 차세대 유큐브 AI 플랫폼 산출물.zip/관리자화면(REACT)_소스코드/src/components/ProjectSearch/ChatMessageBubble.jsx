import React, { useState } from 'react';

function ChatMessageBubble(props) {
    
    if(props.type == "user" && props.message){
        return (
            <div class="message user-message">
                <h5>User:</h5>
                <p>{props.message}</p>
            </div>
        );
    }else if(props.type == "ai" && props.message) {
        return (
            <div class="message ai-message">
                <h5>Answer:</h5>
                <p>{props.message}</p>
            </div>
        );
    }
}

export default ChatMessageBubble;