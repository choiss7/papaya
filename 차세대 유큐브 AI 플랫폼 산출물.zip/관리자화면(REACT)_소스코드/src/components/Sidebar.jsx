import React from "react";
import { Link } from "react-router-dom";
import { Nav } from "react-bootstrap";

function Sidebar() {
  return (
    <div className="shadow-sm p-3 mb-5 bg-body-tertiary rounded">
      <Nav className="navbar bg-body-tertiary flex-column">
        <div className="container-fluid">
          <Link to="/project" className="navbar-brand">
            홈
          </Link>
        </div>
        {/*<div className="container-fluid">
                <Link to="/index" className="navbar-brand">벡터 인덱스</Link>
            </div>
            <div className="container-fluid">
                <Link to="/sss/rag" className="navbar-brand">RAG 파일 목록</Link>
            </div>
            <div className="container-fluid">
                <Link to="/sss/analysis" className="navbar-brand">분석용 파일 목록</Link>
            </div>
            */}
        <div className="container-fluid">
          <Link to="/nudp" className="navbar-brand">
            NUDP
          </Link>
        </div>
      </Nav>
    </div>
  );
}

export default Sidebar;
