import { useState, useEffect } from "react";
import axios from "axios";
import { Link, useParams } from "react-router-dom";
import { SyncLoader } from "react-spinners";

function DataSourceList() {
  const { id } = useParams();

  const [projectList, setProjectList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const URL = import.meta.env.VITE_URL_DS_LIST;
    axios
      .get(URL, {
        params: {
          kb_id: id,
        },
      })
      .then((response) => {
        console.log(response);
        setProjectList(response.data);
      })
      .catch((error) => {
        console.error("Error fetching data: ", error);
      })
      .finally(() => {
        setLoading(false);
      });
  }, [id]);

  if (loading)
    return (
      <div>
        <h3>데이터 소스 목록을 가져오는 중입니다.</h3>
        <SyncLoader />
      </div>
    );

  const handleDelete = async (kb_id, ds_id) => {
    const userConfirmed = confirm(
      "해당 데이터 소스를 정말로 삭제하시겠습니까?"
    );

    if (userConfirmed) {
      try {
        setDeleting(true);

        const URL = import.meta.env.VITE_URL_DS_DELETE;

        const response = await axios.get(URL, {
          params: {
            kb_id: kb_id,
            ds_id: ds_id,
          },
        });

        console.log("response :", response);

        // 프로젝트 목록에서 해당 파일 삭제
        setProjectList((prevProjects) =>
          prevProjects.filter((project) => project.id !== ds_id)
        );

        alert("데이터 소스가 성공적으로 삭제되었습니다!");
      } catch (error) {
        console.error("데이터 소스 삭제 중 오류가 발생했습니다:", error);
        alert("데이터 소스 삭제에 실패했습니다.");
      } finally {
        setDeleting(false);
      }
    } else {
      console.log("삭제가 취소되었습니다.");
    }
  };

  if (deleting)
    return (
      <div>
        <h3>데이터 소스를 삭제하는 중입니다.</h3>
        <SyncLoader />
      </div>
    );

  return (
    <div className="container">
      {/* 타이틀 영역 */}
      <div className="text-start">
        <p className="fs-4 fw-bolder">데이터 소스 목록</p>
      </div>
      {/* 버튼 영역 */}
      <div className="d-flex justify-content-end">
        <Link to={`/sss/rag/${id}`} className="btn btn-primary m-1">
          RAG 파일 목록
        </Link>
        <Link to={`/sss/analysis/${id}`} className="btn btn-primary m-1">
          분석용 파일 목록
        </Link>
      </div>
      <div className="d-flex justify-content-end">
        <Link to={`/ds/new/${id}`} className="btn btn-primary m-1">
          데이터 소스 생성
        </Link>
      </div>
      {/* 리스트 영역 */}
      <div>
        <table className="table">
          <thead>
            <tr>
              <th scope="col">ID</th>
              <th scope="col">이름</th>
              {/*<th scope="col">상태</th>*/}
              <th scope="col">생성날짜</th>
              <th scope="col">삭제</th>
            </tr>
          </thead>
          <tbody>
            {projectList &&
              projectList.map((project) => (
                <tr key={project.id}>
                  <td>{project.id}</td>
                  <td>
                    <Link to={`/ds/detail/${id}/${project.id}`}>
                      {project.name}
                    </Link>
                  </td>
                  {/*<td>{project.status}</td>*/}
                  <td>{project.updatedAt}</td>
                  <td>
                    <button
                      onClick={() => handleDelete(id, project.id)}
                      className="btn btn-danger"
                    >
                      🗑️
                    </button>
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default DataSourceList;
