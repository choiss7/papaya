import { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import axios from 'axios';

function ProjectEdit() {
    const { id } = useParams();
    const [project, setProject] = useState([]);

    useEffect(() => {
        axios.get('https://hyxoebxgvbfk6vcnwlwb5p6wki0kghkt.lambda-url.ap-northeast-2.on.aws/')
          .then(response => {
            console.log(response);
            setProject(response.data);
          })
          .catch(error => {
            console.error('Error fetching data: ', error);
          });
      }, []);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setProject(prevInputs => ({
          ...prevInputs,
          [name]: value
        }));
      };

    const handleSaveProject = (event) => {
        // 기본 동작 방지 (필요한 경우)
        event.preventDefault();
        
        console.log('Link가 클릭되었습니다!');
    };

    return (
        <div>
            {/* 타이틀 영역 */}
            <div className='text-start'>
                <p className="fs-4 fw-bolder">Modify Project</p>
            </div>
            {/* 버튼 영역 */}
            <div className="d-flex justify-content-end">
                <Link to="/project" className='btn btn-primary m-1'>목록</Link>
                <Link to={`/project/${id}`} className='btn btn-primary m-1'>상세정보</Link>
                <Link onClick={handleSaveProject} className='btn btn-primary m-1'>저장</Link>
            </div>
            <div className="container mt-5 ">
                <table className="table text-start table-bordered">
                    <tbody>
                        <tr>
                            <td style={{width: "140px"}} className='px-3 py-2'>id</td>
                            <td className='px-3 py-2'>{project.id} (파라미터:{id})</td>
                        </tr>
                        <tr>
                            <td className='px-3 py-2'>title</td>
                            <td className='px-3 py-2'>{project.title}</td>
                        </tr>
                        <tr>
                            <td className='px-3 py-2'>model</td>
                            <td className='px-3 py-2'>{project.model}</td>
                        </tr>
                        <tr>
                            <td className='px-3 py-2'>S3 path</td>
                            <td className='px-3 py-2'>{project.s3Path}</td>
                        </tr>
                        <tr>
                            <td className='px-3 py-2'>createdTime</td>
                            <td className='px-3 py-2'>{project.createdTime}</td>
                        </tr>
                        <tr>
                            <td className='px-3 py-2'>prompt</td>
                            <td className='px-3 py-2'>
                                <textarea className="form-control" 
                                    id="prompt" name="prompt" rows="10"
                                    value={project.prompt}
                                    onChange={handleChange}
                                    defaultValue=""></textarea>
                            </td>
                        </tr>
                        <tr>
                            <td className='px-3 py-2'>files for RAG</td>
                            <td className='px-3 py-2'>
                                <ul>
                                {project && project.uploadedFiles && project.uploadedFiles.length > 0 
                                && project.uploadedFiles.map((file, index) => (
                                    <li key={index}>{file}</li>
                                ))}
                                </ul>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    )
}

export default ProjectEdit;