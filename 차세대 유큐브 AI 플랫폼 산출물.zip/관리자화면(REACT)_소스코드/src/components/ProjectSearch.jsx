import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link, useParams } from 'react-router-dom';

import './ProjectSearch.css'

import ChatMessageBubble from './ProjectSearch/ChatMessageBubble'

// 검색 화면
function ProjectSearch() {
    const { id } = useParams();    

    return (
        <div className="container">
            {/* 타이틀 영역 */}
            <div className='text-start'>
                <p className="fs-4 fw-bolder">Search</p>
            </div>
            {/* 버튼 영역 */}
            <div className="d-flex justify-content-end">
                <Link to="/project" className='btn btn-primary m-1'>목록</Link>
                <Link to={`/project/${id}`} className='btn btn-primary m-1'>상세정보</Link>
            </div>
            {/* 질문 출력 영역 */}
            <div>
                {/* 출력 영역 */}
                <div className="text-start mt-5 scrollable-div">
                    <div className="chat-container">
                        {/* 채팅 메시지 출력 */}
                        <ChatMessageBubble type="user" message="What is the capital of France?"/>
                        <ChatMessageBubble type="ai" message="The capital of France is Paris. Paris is not only the capital but also the largest city in France. It's known for its iconic landmarks such as the Eiffel Tower, the Louvre Museum, and Notre-Dame Cathedral."/>
                        <ChatMessageBubble type="user" message="Can you tell me more about Paris?"/>
                        <ChatMessageBubble type="ai" message="Paris has a rich history dating back to the 3rd century BC and has been a major center of finance, diplomacy, commerce, fashion, science, and the arts in Europe throughout its history."/>
                    </div>
                </div>
                {/* 질문 영역 */}
                <div className="input-group mb-3">
                    <input type="text" className="form-control" placeholder="메시지를 입력하세요..."/>
                    <button className="btn btn-primary" type="button">전송</button>
                </div>
            </div>
        </div>
    )
}

export default ProjectSearch;