import { useState, useEffect } from "react";
import axios from "axios";
import { Link, useNavigate, useParams } from "react-router-dom";
import { SyncLoader } from "react-spinners";

const FileSelectionComponent = ({ files, onSelect }) => {
  return (
    <div>
      <p>RAG 파일 목록</p>
      {files && files.length > 0 ? (
        files.map((file, index) => (
          <div key={index} style={{ textAlign: "left" }}>
            <input
              type="radio"
              id={`file-${index}`}
              name="fileSelection"
              value={file.file}
              onChange={() => onSelect(file.file)}
              style={{ marginRight: "10px" }} // 라디오 버튼과 라벨 사이에 빈칸 추가
            />
            <label htmlFor={`file-${index}`}>{file.file}</label>
          </div>
        ))
      ) : (
        <p>선택 가능한 파일이 없습니다.</p>
      )}
    </div>
  );
};

function DataSourceNew() {
  const { id } = useParams();

  const navigate = useNavigate();
  const [creating, setCreating] = useState(false);
  const [loading, setLoading] = useState(false);

  const [files, setFiles] = useState([]);

  const [dataSource, setDataSource] = useState([
    { name: "", desc: "", token: "300", overlap: "20", rag_file: "" },
  ]);

  const handleFileSelect = (selectedFile) => {
    if (selectedFile === "RAG 파일 전체") {
      selectedFile = "";
    }

    setDataSource((prevInputs) => ({
      ...prevInputs,
      rag_file: selectedFile,
    }));
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setDataSource((prevInputs) => ({
      ...prevInputs,
      [name]: value,
    }));
  };

  useEffect(() => {
    // 파일 목록을 불러오는 로직을 추가
    const fetchFiles = async () => {
      try {
        setLoading(true);

        const URL = import.meta.env.VITE_URL_S3_LIST;
        const response = await axios.get(URL, {
          params: {
            kb_id: id,
            sub_bucket: "rag",
          },
        }); // 파일 목록 API 호출

        response.data = [{ file: "RAG 파일 전체" }, ...response.data];
        setFiles(response.data);
      } catch (error) {
        console.error("파일 목록을 불러오는 중 오류가 발생했습니다:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchFiles();
  }, [id]);

  const handleNewProject = async (e) => {
    e.preventDefault();

    if (!dataSource.name || dataSource.name.trim() === "") {
      alert("데이터 소스 이름 값이 비어 있습니다!");
      return;
    }

    try {
      setCreating(true);

      const URL = import.meta.env.VITE_URL_DS_CREATE;
      const response = await axios.get(URL, {
        params: {
          kb_id: id,
          name: dataSource.name,
          desc: dataSource.desc,
          token: dataSource.token,
          overlap: dataSource.overlap,
          rag_file: dataSource.rag_file,
        },
      });

      console.log("response :", response);

      alert("데이터 소스가 성공적으로 생성되었습니다!");
      navigate("/ds/" + id);
    } catch (error) {
      console.error("데이터 소스 생성 중 오류가 발생했습니다:", error);

      if (error.response.status == 409) {
        alert("이미 같은 이름의 데이터 소스가 존재합니다.");
      } else if (error.response.status == 400) {
        alert("데이터 소스 생성시 인자값이 잘못되었습니다.");
      } else if (error.response.status == 413) {
        alert("데이터 소스 생성 최대치를 넘었습니다.");
      } else {
        alert("데이터 소스 생성에 실패했습니다.");
      }
    } finally {
      setCreating(false); // 요청 완료 후 로딩 상태를 false로 설정
    }
  };

  if (creating)
    return (
      <div>
        <h3>데이터 소스 생성중입니다.</h3>
        <SyncLoader />
      </div>
    );

  if (loading)
    return (
      <div>
        <h3>RAG 파일 목록을 가져오는 중입니다.</h3>
        <SyncLoader />
      </div>
    );

  return (
    <div>
      {/* 타이틀 영역 */}
      <div className="text-start">
        <p className="fs-4 fw-bolder">데이터 소스 생성</p>
      </div>
      {/* 버튼 영역 */}
      <div className="d-flex justify-content-end">
        <Link to={`/sss/rag/${id}`} className="btn btn-primary m-1">
          RAG 파일 목록
        </Link>
        <Link to={`/sss/analysis/${id}`} className="btn btn-primary m-1">
          분석용 파일 목록
        </Link>
      </div>
      <div className="d-flex justify-content-end">
        <Link to={`/ds/${id}`} className="btn btn-primary m-1">
          데이터 소스 목록
        </Link>
        <Link onClick={handleNewProject} className="btn btn-primary m-1">
          생성
        </Link>
      </div>
      <div className="container mt-5 ">
        <table className="table text-start table-bordered">
          <tbody>
            <tr>
              <td style={{ width: "140px" }} className="px-3 py-2">
                이름
              </td>
              <td className="px-3 py-2">
                <input
                  type="text"
                  id="name"
                  name="name"
                  className="w-100"
                  value={dataSource.name ? dataSource.name : ""}
                  onChange={handleChange}
                />
              </td>
            </tr>
            <tr>
              <td className="px-3 py-2">설명</td>
              <td className="px-3 py-2">
                <input
                  type="text"
                  id="desc"
                  name="desc"
                  className="w-100"
                  value={dataSource.desc ? dataSource.desc : ""}
                  onChange={handleChange}
                />
              </td>
            </tr>
            <tr>
              <td className="px-3 py-2">최대 토큰</td>
              <td className="px-3 py-2">
                <input
                  type="text"
                  id="token"
                  name="token"
                  className="w-100"
                  value={dataSource.token ? dataSource.token : 300}
                  onChange={handleChange}
                />
              </td>
            </tr>
            <tr>
              <td className="px-3 py-2">오버랩 비율</td>
              <td className="px-3 py-2">
                <input
                  type="text"
                  id="overlap"
                  name="overlap"
                  className="w-100"
                  value={dataSource.overlap ? dataSource.overlap : 20}
                  onChange={handleChange}
                />
              </td>
            </tr>
            <tr>
              <td className="px-3 py-2">RAG 파일</td>
              <td className="px-3 py-2">
                <input
                  type="text"
                  id="rag_file"
                  name="rag_file"
                  className="w-100"
                  value={dataSource.rag_file ? dataSource.rag_file : ""}
                />
              </td>
            </tr>
            <tr>
              <td className="px-3 py-2">RAG 파일 선택</td>
              <td className="px-3 py-2">
                {/* 파일 선택 컴포넌트 삽입 */}
                <FileSelectionComponent
                  files={files}
                  onSelect={handleFileSelect}
                />
              </td>
            </tr>
            {/*<tr>
                            <td className='px-3 py-2'>createdTime</td>
                            <td className='px-3 py-2'>{project.createdTime}</td>
                        </tr>*/}
            {/*<tr>
                            <td className='px-3 py-2'>files</td>
                            <td className='px-3 py-2'>
                                <ul>
                                {project && project.uploadedFiles && project.uploadedFiles.length > 0 
                                && project.uploadedFiles.map((file, index) => (
                                    <li key={index}>{file}</li>
                                ))}
                                </ul>
                            </td>
                        </tr>*/}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default DataSourceNew;
