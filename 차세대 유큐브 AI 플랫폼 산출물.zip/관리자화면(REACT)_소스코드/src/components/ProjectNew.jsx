import { useState, useEffect } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import { SyncLoader } from "react-spinners";

const IndexSelectionComponent = ({ indices, onSelect }) => {
  return (
    <div>
      <p>벡터 인덱스 목록</p>
      {indices && indices.length > 0 ? (
        indices.map((index, i) => (
          <div key={i} style={{ textAlign: "left" }}>
            <input
              type="radio"
              id={`index-${i}`}
              name="indexSelection"
              value={index.index_name}
              onChange={() => onSelect(index.index_name)}
              style={{ marginRight: "10px" }} // 라디오 버튼과 라벨 사이에 빈칸 추가
            />
            <label htmlFor={`index_name-${i}`}>{index.index_name}</label>
          </div>
        ))
      ) : (
        <p>선택 가능한 벡터 인덱스가 없습니다.</p>
      )}
    </div>
  );
};

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

function ProjectNew() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [creating, setCreating] = useState(false);
  const [project, setProject] = useState({
    name: "",
    desc: "",
    tag: "",
    prompt: "",
  });
  const [indices, setIndices] = useState([]);

  const handleIndexSelect = (selectedIndex) => {
    setProject((prevInputs) => ({
      ...prevInputs,
      index: selectedIndex,
    }));
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setProject((prevInputs) => ({
      ...prevInputs,
      [name]: value,
    }));
  };

  {
    /*}
      useEffect(() => {

        const fetchIndices = async () => {
            try {

                setLoading(true)
                const response = await axios.get('https://i6m52i7ezj.execute-api.us-east-1.amazonaws.com/prod'); // 벡터 인덱스 목록 API 호출
                setIndices(response.data);
            } catch (error) {
                console.error('벡터 인덱스 목록을 불러오는 중 오류가 발생했습니다:', error);
            } finally {
                setLoading(false)
            }
        };
        fetchIndices();
     }, []);
     */
  }

  const handleNewProject = async (e) => {
    // 기본 동작 방지 (필요한 경우)
    e.preventDefault();

    if (!project.name || project.name.trim() === "") {
      alert("프로젝트 이름 값이 비어 있습니다!");
      return;
    }

    try {
      setCreating(true);

      // 1. 벡터 인덱스 생성
      const URL1 = import.meta.env.VITE_URL_INDEX_CREATE;

      const response1 = await axios.get(URL1, {
        params: {
          index_name: project.name,
        },
      });

      console.log("response1 : ", response1.data);

      // 2. 지식기반 생성
      const URL2 = import.meta.env.VITE_URL_KB_CREATE;

      const response2 = await axios.get(URL2, {
        params: {
          name: project.name,
          desc: project.desc,
          tag: project.tag,
          index_name: response1.data,
        },
      });

      console.log("response2 : ", response2);

      const kb_id = response2.data.knowledgeBaseId;

      // 3. RAG 템플릿 저장
      const URL3 = import.meta.env.VITE_URL_TEMPLATE_CREATE;

      const response3 = await axios.get(URL3, {
        params: {
          kb_id: kb_id,
          prompt: project.prompt,
        },
      });

      console.log("response3 : ", response3);

      alert("프로젝트가 성공적으로 생성되었습니다!");
      navigate("/project");
    } catch (error) {
      console.error("프로젝트 생성 중 오류가 발생했습니다:", error);

      if (error.response.status == 409) {
        alert("이미 같은 이름의 프로젝트가 존재합니다.");
      } else if (error.response.status == 400) {
        alert("프로젝트 생성시 인자값이 잘못되었습니다.");
      } else {
        alert("프로젝트 생성에 실패했습니다.");
      }
    } finally {
      setCreating(false); // 요청 완료 후 로딩 상태를 false로 설정
    }
  };

  if (creating)
    return (
      <div>
        <h3>
          프로젝트 생성중입니다.<br></br>
          (벡터 인덱스 생성에 시간이 오래 소요될 수 있습니다.)
        </h3>
        <SyncLoader />
      </div>
    );

  if (loading)
    return (
      <div>
        <h3>벡터 인덱스 목록을 가져오는 중입니다.</h3>
        <SyncLoader />
      </div>
    );

  return (
    <div>
      {/* 타이틀 영역 */}
      <div className="text-start">
        <p className="fs-4 fw-bolder">프로젝트 생성</p>
      </div>
      {/* 버튼 영역 */}
      <div className="d-flex justify-content-end">
        <Link to="/project" className="btn btn-primary m-1">
          프로젝트 목록
        </Link>
        <Link onClick={handleNewProject} className="btn btn-primary m-1">
          생성
        </Link>
      </div>
      <div className="container mt-5 ">
        <table className="table text-start table-bordered">
          <tbody>
            <tr>
              <td style={{ width: "140px" }} className="px-3 py-2">
                이름
              </td>
              <td className="px-3 py-2">
                <input
                  type="text"
                  id="name"
                  name="name"
                  className="w-100"
                  value={project.name ?? ""}
                  onChange={handleChange}
                />
              </td>
            </tr>
            <tr>
              <td className="px-3 py-2">설명</td>
              <td className="px-3 py-2">
                <input
                  type="text"
                  id="desc"
                  name="desc"
                  className="w-100"
                  value={project.desc ?? ""}
                  onChange={handleChange}
                />
              </td>
            </tr>
            {/*<tr>
                <td className='px-3 py-2'>createdTime</td>
                <td className='px-3 py-2'>{project.createdTime}</td>
            </tr>*/}
            <tr>
              <td className="px-3 py-2">프롬프트</td>
              <td className="px-3 py-2">
                <textarea
                  className="form-control"
                  id="prompt"
                  name="prompt"
                  rows="5"
                  value={project.prompt ?? ""}
                  onChange={handleChange}
                  defaultValue=""
                ></textarea>
              </td>
            </tr>
            <tr>
              <td className="px-3 py-2">태그</td>
              <td className="px-3 py-2">
                <textarea
                  className="form-control"
                  id="tag"
                  name="tag"
                  rows="3"
                  value={project.tag ?? ""}
                  onChange={handleChange}
                  defaultValue=""
                ></textarea>
              </td>
            </tr>
            {/*
            <tr>
                <td className='px-3 py-2'>벡터 인덱스</td>
                <td className='px-3 py-2'>
                    <input
                        type="text"
                        id="index"
                        name="index"
                        className='w-100'
                        value={project.index}
                        onChange={handleChange}
                        />
                </td>
            </tr>
            <tr>
                <td className='px-3 py-2'>벡터 인덱스 선택</td>
                <td className='px-3 py-2'>
                    <IndexSelectionComponent indices={indices} onSelect={handleIndexSelect} />
                </td>
            </tr>
            */}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default ProjectNew;
